function varargout = c1hw01(varargin)
% C1HW01 MATLAB code for c1hw01.fig
%      C1HW01, by itself, creates a new C1HW01 or raises the existing
%      singleton*.
%
%      H = C1HW01 returns the handle to a new C1HW01 or the handle to
%      the existing singleton*.
%
%      C1HW01('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in C1HW01.M with the given input arguments.
%
%      C1HW01('Property','Value',...) creates a new C1HW01 or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before c1hw01_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to c1hw01_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help c1hw01

% Last Modified by GUIDE v2.5 24-Sep-2019 14:09:10

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @c1hw01_OpeningFcn, ...
                   'gui_OutputFcn',  @c1hw01_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before c1hw01 is made visible.
function c1hw01_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to c1hw01 (see VARARGIN)

% Choose default command line output for c1hw01
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes c1hw01 wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = c1hw01_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in pushbutton1.
%load�Ĥ@�i�Ϥ�
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[filename pathname]=uigetfile({'*.jpg';'*.bmp';'*.png';'*.tif'},'Select image','C:\Users\USER\desktop');
if(filename ~=0)
    img=strcat(pathname, filename);
    fileID = fopen(img,'r');
    A = fscanf(fileID,'%s');
    fclose(fileID);
    
else
    return;
end
%�H�W�ϥ�file selection dialog box���覡���ϥΪ̨M�w�}�Ҫ��Ϥ� �w�]��m�b�ୱ
img64 = zeros(64,64);
keySet = {'0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V'};
valueSet = [0 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 30 31];
M = containers.Map(keySet, valueSet);
%�إߤ@��Map��.64���ഫ��imshow�i�HŪ����matrix
count = zeros(1,32);
%count�ܼƥΨӺ�C�ӦǶ��X�{������
for i=1:64
    for j=1:64
        img64(i,j) = M(A((i-1)*64+j));
        count(M(A((i-1)*64+j))+1) = count(M(A((i-1)*64+j))+1)+1;
    end
end
%�䤣�쪽�����32�Ƕ�����k �ҥH������32�Ƕ�����*8 �ন256�ӦǶ�
 img256 = img64.*8;
 img256 = uint8(img256);
 axes(handles.axes1)
 imshow(img256)
 handles.img1 = img256;
 guidata(hObject, handles);
 %��ܦbaxes1�Paxes2�W �é��handles�̨Ѩ�Lpushbutton callbacl�s��
 axes(handles.axes2)
 bar(count)
 handles.count1 = count;
 guidata(hObject, handles);


%���ϥΪ̿�J�n�[����ƶq�P���v
function edit1_Callback(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1 as text
%        str2double(get(hObject,'String')) returns contents of edit1 as a double


% --- Executes during object creation, after setting all properties.
function edit1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%�[�X�ӦǶ��W�h ���32�Ƕ�����ǤW
% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
img1 = handles.img1;
num = str2num(get(handles.edit1, 'String')); %��ϥΪ̿�J���Ʀr
img1 = img1+num*8;                           %�]��imshow�O��256�Ƕ� �ҥH�n*8
new_count1 = zeros(1,32);
axes(handles.axes3)
imshow(img1)

img64 = round(img1/8);                       %���s�p��s���Ϥ���histogram
for i=1:32
    new_count1(i) = sum(img64(:) == i);
end
axes(handles.axes4)
bar(new_count1)

%�򥻤W�Mpushbutton2���ާ@�@�� �u�O�[������
% --- Executes on button press in pushbutton3.
function pushbutton3_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
img1 = handles.img1;
count1 = handles.count1;
num = str2num(get(handles.edit1, 'String'));
img1 = img1-num*8;
new_count1 = zeros(1,32);
axes(handles.axes3)
imshow(img1)
img64 = round(img1/8);
for i=1:32
    new_count1(i) = sum(img64(:) == i);
end
axes(handles.axes4)
bar(new_count1)

%load�i�ĤG�i�Ϥ� �Mpushbutton1��code�ۦP ��ܦ�m���P�ӥH
% --- Executes on button press in pushbutton4.
function pushbutton4_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[filename pathname]=uigetfile({'*.jpg';'*.bmp';'*.png';'*.tif'},'Select image','C:\Users\USER\desktop');
if(filename ~=0)
    img=strcat(pathname, filename);
    fileID = fopen(img,'r');
    A = fscanf(fileID,'%s');
    fclose(fileID);
    
else
    return;
end
img64 = zeros(64,64);
keySet = {'0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V'};
valueSet = [0 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 30 31];
M = containers.Map(keySet, valueSet);
count = zeros(1,32);
for i=1:64
    for j=1:64
        img64(i,j) = M(A((i-1)*64+j));
        count(M(A((i-1)*64+j))+1) = count(M(A((i-1)*64+j))+1)+1;
    end
end
 img256 = img64.*8;
 img256 = uint8(img256);
 axes(handles.axes5)
 imshow(img256)
 handles.img2 = img256;
 guidata(hObject, handles);
 
 axes(handles.axes6)
 bar(count)
 handles.count2 = count;
 guidata(hObject, handles);

%multiply
% --- Executes on button press in pushbutton5.
function pushbutton5_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
img1 = handles.img1;
num = str2num(get(handles.edit1, 'String'));
img1 = img1*num;                              %�M�[��ާ@�@�� �u�O����*num
axes(handles.axes3)
imshow(img1)
new_count1 = zeros(1,32);
img64 = round(img1/8);
for i=1:32
    new_count1(i) = sum(img64(:) == i);
end
axes(handles.axes4)
bar(new_count1)

%��i�Ϫ�����
% --- Executes on button press in pushbutton6.
function pushbutton6_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
img1 = handles.img1;
img2 = handles.img2;
count1 = handles.count1;
count2 = handles.count2;                  %�qhandles�̧��i�Ϫ�matrix�Mhistogram���
avgimg = (img1+img2)./2;                  %�M�ᥭ�� �A��X
avgcount = (count1+count2)./2;
axes(handles.axes3)
imshow(avgimg)
axes(handles.axes4)
bar(avgcount)

%g(x,y) = f(x,y) - f(x-1,y)
% --- Executes on button press in pushbutton7.
function pushbutton7_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
img1 = handles.img1;
new_img1 = img1;
for i=2:64
    new_img1(i,:) = new_img1(i,:)-img1(i-1,:);    %�N�@�Ӥ@�Ӵ�
end
axes(handles.axes7)
imshow(new_img1)

new_count1 = zeros(1,32);
img64 = round(new_img1/8);
for i=1:32
    new_count1(i) = sum(img64(:) == i);
end
axes(handles.axes8)
bar(new_count1)
