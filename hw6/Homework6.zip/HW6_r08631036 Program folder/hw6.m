function varargout = hw6(varargin)
% HW6 MATLAB code for hw6.fig
%      HW6, by itself, creates a new HW6 or raises the existing
%      singleton*.
%
%      H = HW6 returns the handle to a new HW6 or the handle to
%      the existing singleton*.
%
%      HW6('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in HW6.M with the given input arguments.
%
%      HW6('Property','Value',...) creates a new HW6 or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before hw6_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to hw6_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help hw6

% Last Modified by GUIDE v2.5 03-Dec-2019 17:53:24

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @hw6_OpeningFcn, ...
                   'gui_OutputFcn',  @hw6_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before hw6 is made visible.
function hw6_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to hw6 (see VARARGIN)

% Choose default command line output for hw6
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes hw6 wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = hw6_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[filename pathname]=uigetfile({'*.bmp';'*.jpg'},'Select image','C:\Users\SSL108\Desktop\�v���B�z\hw6\Part 1 Image');
if(filename ~=0)
    img=strcat(pathname, filename);
    fileID = fopen(img,'r');
    A = fscanf(fileID,'%s');
    fclose(fileID);
else
    return;
end
img = imread(img);
handles.img = img;
guidata(hObject,handles);
axes(handles.axes1)
imshow(img)


% --- Executes on selection change in popupmenu1.
function popupmenu1_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu1 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu1
index = get(handles.popupmenu1,'Value');
img = handles.img;
ratio_w = str2double(handles.ratio_w);
ratio_h = str2double(handles.ratio_h);
switch index
    case 1
        J = trapezoid(img,ratio_w,ratio_h);
        axes(handles.axes2)
        imshow(J)
    case 2
        J = wavy(img);
        axes(handles.axes2)
        imshow(J)
    case 3
        J = circular(img);
        axes(handles.axes2)
        imshow(J)
end


% --- Executes during object creation, after setting all properties.
function popupmenu1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function output = trapezoid(img,ratio_w,ratio_h)
[w,h,channel] = size(img);
new_w = w*ratio_w;
new_h = h*ratio_h;
output = zeros(size(img,1),size(img,2),3);
for i=1:new_h
    for j=round(w/2-(round(new_w*i/new_h) + (new_h-i)*w/new_h)/2)+1:round(w/2+(round(new_w*i/new_h) + (new_h-i)*w/new_h)/2)
        for k=1:3
            wtf =  (j-round(w/2-(round(new_w*i/new_h) + (new_h-i)*w/new_h)/2))/round(round(new_w*i/new_h) + (new_h-i)*w/new_h);
            if round(j*wtf)>(w-1)
                output(i,j,k) = img(round(i/ratio_h),round(j*wtf),k);
            else
                output(i,j,k) = img(round(i/ratio_h),round(j*wtf)+1,k);
            end
        end
    end
end
output = uint8(output);

function output = wavy(img)
[w,h,channel] = size(img);
output = zeros(size(img,1),size(img,2),3);
for i=1:w
    for j=1:h
        for k=1:3
            u = i-20*sin(2*pi*j/128);
            v = j-20*sin(2*pi*i/128);
            
            d1 = u-floor(u);
            d2 = v-floor(v);
            
            if (((v>=1)&&(v<w))&&((u>=1)&&(u<h)))
                output(i,j,k) = (1-d1)*(1-d2)*img(floor(u),floor(v),k)+...
                                (1-d1)*d2*img(floor(u),floor(v)+1,k)+...
                                d1*(1-d2)*img(floor(u)+1,floor(v),k)+...
                                d1*d2*img(floor(u)+1,floor(v)+1,k);
            end
        end
    end
end
output = uint8(output);
            
function output=circular(img)
[w,h,channel] = size(img);
output = zeros(size(img,1),size(img,2),3);
for i=1:w
    for j=1:h
        for k=1:3
            d = sqrt((h/2)^2-(h/2-i)^2);
            if d==0; d=1; end
            u = round((j-w/2)*d/(w/2)+w/2);
            v = i;
            output(v,u,k) = img(i,j,k);
        end
    end
end
output = uint8(output);


% --- Executes on selection change in popupmenu2.
function popupmenu2_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu2 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu2
set(handles.text4,'String','Calculating')
index = get(handles.popupmenu2,'Value');
wname = handles.wname;
level = handles.level;
wname = string(wname);
level = str2double(level);
axes(handles.axes3)
switch index
    case 1
        img1 = imread('clock1.JPG');
        img2 = imread('clock2.JPG');
        output = wfusimg(img1,img2,wname,level,'mean','max');
        output = uint8(output);
        imshow(output)
    case 2
        img1 = imread('multifocus1.JPG');
        img2 = imread('multifocus2.JPG');
        img3 = imread('multifocus3.JPG');
        output = wfusimg(img1,img2,wname,level,'mean','max');
        output = wfusimg(output,img3,wname,level,'mean','max');
        output = uint8(output);
        imshow(output)
    case 3
        img1 = imread('MRI1.JPG');
        img2 = imread('MRI2.JPG');
        img1(:,:,2) = zeros(size(img1,1),size(img1,2)); img1(:,:,3) = zeros(size(img1,1),size(img1,2));
        img2(:,:,2) = zeros(size(img2,1),size(img2,2)); img2(:,:,3) = zeros(size(img2,1),size(img2,2));
        output = wfusimg(img1,img2,wname,level,'mean','max');
        output = uint8(output);
        output = output(:,:,1);
        imshow(output)
end
set(handles.text4,'String','Done')

% --- Executes during object creation, after setting all properties.
function popupmenu2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function output = fusion(wname,level,img1,img2,img3)
switch nargin
    case 4
        [c1,s1] = wavedec2(img1,level,wname);
        [c2,s2] = wavedec2(img2,level,wname);
        [H1,V1,D1] = detcoef2('all',c1,s1,level);
        A1 = appcoef2(c1,s1,wname,level);
        [H2,V2,D2] = detcoef2('all',c2,s2,level);
        A2 = appcoef2(c2,s2,wname,level);
        V1img = wcodemat(V1,255,'mat',1);
        H1img = wcodemat(H1,255,'mat',1);
        D1img = wcodemat(D1,255,'mat',1);
        A1img = wcodemat(A1,255,'mat',1);
        
        for i=1:size(cA1,1)
            for j=1:size(cA1,2)
                for k=1:3
                    cH3(i,j,k) = max(cH1(i,j,k),cH2(i,j,k));
                    cV3(i,j,k) = max(cV1(i,j,k),cV2(i,j,k));
                    cD3(i,j,k) = max(cD1(i,j,k),cD2(i,j,k));
                end
            end
        end
        output = idwt2(cA3,cH3,cV3,cD3,wname);
    case 5
        [cA1,cH1,cV1,cD1] = dwt2(img1,wname);
        [cA2,cH2,cV2,cD2] = dwt2(img2,wname);
        [cA3,cH3,cV3,cD3] = dwt2(img3,wname);
        cA4 = (cA1+cA2+cA3)/3;
        cH4 = zeros(size(cA1,1),size(cA1,2),3); cV4 = zeros(size(cA1,1),size(cA1,2),3); cD4 = zeros(size(cA1,1),size(cA1,2),3);
        for i=1:size(cA1,1)
            for j=1:size(cA1,2)
                for k=1:3
                    cH4(i,j,k) = max([cH1(i,j,k) cH2(i,j,k) cH3(i,j,k)]);
                    cV4(i,j,k) = max([cV1(i,j,k) cV2(i,j,k) cV3(i,j,k)]);
                    cD4(i,j,k) = max([cD1(i,j,k) cD2(i,j,k) cD3(i,j,k)]);
                end
            end
        end
        output = idwt2(cA4,cH4,cV4,cD4,wname);
end
output = uint8(output);


% --- Executes on selection change in popupmenu3.
function popupmenu3_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu3 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu3
wnamelist = get(handles.popupmenu3,'String');
index = get(handles.popupmenu3,'Value');
if index == 0
    disp('Please choose from below.')
end
handles.wname = wnamelist(index);
guidata(hObject,handles);


% --- Executes during object creation, after setting all properties.
function popupmenu3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
img = handles.img;
if length(size(img))==3
    img = rgb2gray(img);
end
axes(handles.axes4)
BW = imbinarize(img);
BW = edge(BW,'canny');
[H,T,R] = hough(BW);
P = houghpeaks(H,15,'threshold',ceil(0.1*max(H(:))));
lines = houghlines(BW,T,R,P,'FillGap',30,'MinLength',50);
imshow(img), hold on
for k = 1:length(lines)
   xy = [lines(k).point1; lines(k).point2];
   plot(xy(:,1),xy(:,2),'LineWidth',2,'Color','green');
   plot(xy(1,1),xy(1,2),'x','LineWidth',2,'Color','yellow');
   plot(xy(2,1),xy(2,2),'x','LineWidth',2,'Color','red');
end
area = regionprops(imbinarize(img),'area');
perimeter = regionprops(imbinarize(img),'perimeter');
thestring = sprintf('Area:%d mm\nPerimeter:%d mm\n',area.Area*0.25,perimeter.Perimeter*0.5);
set(handles.text5,'String',thestring)



function edit1_Callback(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1 as text
%        str2double(get(hObject,'String')) returns contents of edit1 as a double
level = get(handles.edit1, 'String');
handles.level = level;
guidata(hObject,handles)


% --- Executes during object creation, after setting all properties.
function edit1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit2_Callback(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit2 as text
%        str2double(get(hObject,'String')) returns contents of edit2 as a double
ratio_w = get(handles.edit2,'String');
handles.ratio_w = ratio_w;
guidata(hObject,handles)

% --- Executes during object creation, after setting all properties.
function edit2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit3_Callback(hObject, eventdata, handles)
% hObject    handle to edit3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit3 as text
%        str2double(get(hObject,'String')) returns contents of edit3 as a double
ratio_h = get(handles.edit3,'String');
handles.ratio_h = ratio_h;
guidata(hObject,handles)

% --- Executes during object creation, after setting all properties.
function edit3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton3.
function pushbutton3_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
axes(handles.axes3)
imsave
