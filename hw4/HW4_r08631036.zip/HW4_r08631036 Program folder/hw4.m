function varargout = hw4(varargin)
% HW4 MATLAB code for hw4.fig
%      HW4, by itself, creates a new HW4 or raises the existing
%      singleton*.
%
%      H = HW4 returns the handle to a new HW4 or the handle to
%      the existing singleton*.
%
%      HW4('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in HW4.M with the given input arguments.
%
%      HW4('Property','Value',...) creates a new HW4 or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before hw4_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to hw4_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help hw4

% Last Modified by GUIDE v2.5 05-Nov-2019 21:17:21

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @hw4_OpeningFcn, ...
                   'gui_OutputFcn',  @hw4_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before hw4 is made visible.
function hw4_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to hw4 (see VARARGIN)

% Choose default command line output for hw4
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes hw4 wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = hw4_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[filename pathname]=uigetfile({'*.jpg';'*.bmp'},'Select image','C:\Users\SSL108\desktop');
if(filename ~=0)
    img=strcat(pathname, filename);
    fileID = fopen(img,'r');
    A = fscanf(fileID,'%s');
    fclose(fileID);
else
    return;
end
img = imread(img);
axes(handles.axes1)
imshow(img)

if length(size(img)) == 3
    img = rgb2gray(img);
end

tic
handles.img = img;
guidata(hObject,handles);
fft_img = fft2(img);
fmin = log(1+abs(min(min(fft_img))));
fmax = log(1+abs(max(max(fft_img))));
spectrum = 255*(log(1+abs(fftshift(fft_img)))-fmin)./(fmax-fmin);
phase = angle(fftshift(fft_img));
time = toc;
axes(handles.axes2)
imshow(spectrum,[])
axes(handles.axes3)
imshow(phase)
set(handles.text1, 'String', strcat('Time:',num2str(time)));
axes(handles.axes4)
imshow(uint8(ifft2(fft_img)))
handles.fft_img = fft_img;
guidata(hObject,handles);
axes(handles.axes7)
imshow(imsubtract(img,uint8(ifft2(fft_img))))


% --- Executes on selection change in listbox1.
function listbox1_Callback(hObject, eventdata, handles)
% hObject    handle to listbox1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns listbox1 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from listbox1
index = get(handles.listbox1,'Value');
img = handles.img;
D0 = handles.D0;
imgsize = size(img);
paddedsize = 2*ceil((imgsize(1)+imgsize(2)-1)/2);
switch index
    case 1
        filter = highpass('Ideal',paddedsize,paddedsize,D0,1);
    case 2
        filter = highpass('Butterworth',paddedsize,paddedsize,D0,1);
    case 3
        filter = highpass('Gaussian',paddedsize,paddedsize,D0,1);
    case 4
        filter = lowpass('Ideal',paddedsize,paddedsize,D0,1);
    case 5
        filter = lowpass('Butterworth',paddedsize,paddedsize,D0,1);
    case 6
        filter = lowpass('Gaussian',paddedsize,paddedsize,D0,1);
    case 7
        rh = handles.rh;
        rl = handles.rl;
        [U,V] = dftuv(paddedsize,paddedsize);
        D = sqrt(U.^2+V.^2);
        filter = (rh-rl)*(1-exp((-1.*D.^2)./(D0^2)))+rl;
    case 8
        T = 3;
        a = 0.05;
        b = 0.05;
        [U,V] = dftuv(imgsize(1),imgsize(2));
        filter = (T./((U*a + V*b).*pi)).*(sin(pi.*(U*a + V*b))).*(exp(-1i*pi*(U*a + V*b)));
    case 9
        T = 3;
        a = 0.05;
        b = 0.1;
        [U,V] = dftuv(imgsize(1),imgsize(2));
        filter = (T./((U*a + V*b)*pi)).*(sin(pi*(U*a + V*b))).*(exp(-1i*pi*(U*a + V*b)));
end
handles.filter = filter;
guidata(hObject,handles);
handles.index = index;
guidata(hObject,handles);


% --- Executes during object creation, after setting all properties.
function listbox1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to listbox1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit1_Callback(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1 as text
%        str2double(get(hObject,'String')) returns contents of edit1 as a double
D0 = str2double(get(handles.edit1,'String'));
disp(D0)
handles.D0 = D0;
guidata(hObject,handles);


% --- Executes during object creation, after setting all properties.
function edit1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit2_Callback(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit2 as text
%        str2double(get(hObject,'String')) returns contents of edit2 as a double
rh = str2double(get(handles.edit2,'String'));
handles.rh = rh;
guidata(hObject,handles);

% --- Executes during object creation, after setting all properties.
function edit2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit3_Callback(hObject, eventdata, handles)
% hObject    handle to edit3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit3 as text
%        str2double(get(hObject,'String')) returns contents of edit3 as a double
rl = str2double(get(handles.edit3,'String'));
handles.rl = rl;
guidata(hObject,handles);

% --- Executes during object creation, after setting all properties.
function edit3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
img = handles.img;
filter = handles.filter;
imgsize = size(img);
paddedsize = 2*ceil((imgsize(1)+imgsize(2)-1)/2);

if handles.index == 7
    img = log(1+double(img));
    fft_img = fft2(img,paddedsize,paddedsize);
elseif handles.index == 8 || handles.index == 9
    fft_img = fftshift(fft2(double(img),imgsize(1),imgsize(2)));
else
    fft_img = fft2(double(img),paddedsize,paddedsize);
end
if handles.index == 8 || handles.index == 9
    filter = abs(filter);
    for i = 1:size(filter,1)
       for j = 1:size(filter,2)
           if isnan(filter(i,j))
               filter(i,j) = 3;
           end
       end
    end
end
filtered_img = filter.*fft_img;
noise = wgn(size(filtered_img,1),size(filtered_img,2),1,'complex');
if handles.index == 9
    filtered_img = filtered_img + noise;
    disp(filtered_img)
end
ifft_img = ifft2(filtered_img);
if handles.index == 7
    ifft_img = exp(ifft_img);
end
ifft_img = abs(ifft_img);
ifft_img = ifft_img(1:imgsize(1),1:imgsize(2));

axes(handles.axes5)
imshow(ifft_img,[0 255])

handles.filtered_img = filtered_img;
guidata(hObject,handles);
handles.filter = filter;
guidata(hObject,handles);
handles.noise = noise;
guidata(hObject,handles);

% --- Executes on selection change in listbox2.
function listbox2_Callback(hObject, eventdata, handles)
% hObject    handle to listbox2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns listbox2 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from listbox2
index2 = get(handles.listbox2,'Value');
handles.index2 = index2;
guidata(hObject,handles);


% --- Executes during object creation, after setting all properties.
function listbox2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to listbox2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton3.
function pushbutton3_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
index2 = handles.index2;
switch index2
    case 1
        filtered_img = handles.filtered_img;
        filter = handles.filter;
        deblurred_img = filtered_img./filter;     
        deblurred_img = ifft2(deblurred_img);
        deblurred_img = abs(deblurred_img);
        
    case 2
        filtered_img = handles.filtered_img;
        filter = handles.filter;
        K = 0.0001;
        new_filter = (abs(filter).^2)./((abs(filter).^2) + K)./filter;
        deblurred_img = filtered_img.*new_filter;
        deblurred_img = abs(ifft2(deblurred_img));
end
axes(handles.axes6)
imshow(deblurred_img,[0 255])



function [U,V] = dftuv(M,N)
u = 1:M;
v = 1:N;

idx = find(u > M/2);
u(idx) = u(idx) - M;
idy = find(v > N/2);
v(idy) = v(idy) - N;

[V, U] = meshgrid(v, u);


function filter = lowpass(type,M,N,D0,n)
[U,V] = dftuv(M,N);
D = sqrt(U.^2+V.^2);
switch type
    case 'Ideal'
        filter = double(D <= D0);
    case 'Butterworth'
        filter = 1./(1+(D./D0).^(2*n));
    case 'Gaussian'
        filter = exp((-1.*D.^2)./(2*(D0^2)));
end

function filter = highpass(type,M,N,D0,n)
lp = lowpass(type,M,N,D0,n);
filter = 1-lp;
