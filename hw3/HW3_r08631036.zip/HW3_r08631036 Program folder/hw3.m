function varargout = hw3(varargin)
% HW3 MATLAB code for hw3.fig
%      HW3, by itself, creates a new HW3 or raises the existing
%      singleton*.
%
%      H = HW3 returns the handle to a new HW3 or the handle to
%      the existing singleton*.
%
%      HW3('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in HW3.M with the given input arguments.
%
%      HW3('Property','Value',...) creates a new HW3 or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before hw3_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to hw3_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help hw3

% Last Modified by GUIDE v2.5 22-Oct-2019 11:48:14

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @hw3_OpeningFcn, ...
                   'gui_OutputFcn',  @hw3_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before hw3 is made visible.
function hw3_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to hw3 (see VARARGIN)

% Choose default command line output for hw3
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes hw3 wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = hw3_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on selection change in listbox1.
function listbox1_Callback(hObject, eventdata, handles)
% hObject    handle to listbox1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns listbox1 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from listbox1

index_selected = get(handles.listbox1,'Value');
if index_selected == 1
    mask = [0.3679 0.6065 0.3679;0.6065 1 0.6065;0.3679 0.6065 0.3679]/4.8976;
elseif index_selected == 2
    mask = [1 1 1;1 1 1;1 1 1]/9;
elseif index_selected == 3
    mask = [1 1 1;1 -8 1;1 1 1];
elseif index_selected == 4
    mask = [-1 0 1;-2 0 2;-1 0 1];
elseif index_selected == 5
    mask = [1 2 1;0 0 0;-1 -2 -1];
elseif index_selected == 6
    dim = inputdlg({'Enter the size of your mask'},'Dim',[1 20],{'3'});
    dim = str2double(dim{1,1});
    if mod(dim,2) == 0
        errordlg('Size must be odd','Size Error');
        return
    end
    for i = 1:dim
        prompt = {repmat('element',dim,1)};
        mask{i} = inputdlg(string(prompt{1,1}),'Values',repmat([1 10],dim,1));
    end
    temp=[];
    for i = 1:dim
        temp = [temp str2double(mask{1,i})];
    end
    mask = temp;
elseif index_selected == 7 || index_selected == 8 ||index_selected == 9
    dim = inputdlg({'Enter the dimemsion of your mask'},'Dim',[1 20],{'3'});
    dim = str2double(dim{1,1});
    if mod(dim,2) == 0
        errordlg('Dimension must be odd','Dim Error');
        return
    end
    mask = ones(dim,dim);
end
uit = uitable(hw3);
uit.Data = mask;
uit.Position = [20 200 200 200];
handles.mask = mask;
guidata(hObject,handles);
handles.index = index_selected;
guidata(hObject,handles);


% --- Executes during object creation, after setting all properties.
function listbox1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to listbox1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit1_Callback(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1 as text
%        str2double(get(hObject,'String')) returns contents of edit1 as a double


% --- Executes during object creation, after setting all properties.
function edit1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[filename pathname]=uigetfile({'*.jpg';'*.bmp'},'Select image','C:\Users\SSL108\desktop');
if(filename ~=0)
    img=strcat(pathname, filename);
    fileID = fopen(img,'r');
    A = fscanf(fileID,'%s');
    fclose(fileID);
else
    return;
end
img = imread(img);
axes(handles.axes1)
imshow(img)
handles.img = img;
guidata(hObject,handles);


% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
tic
img = handles.img;
mask = handles.mask;
index = handles.index;
mask = fliplr(mask);
mask = flipud(mask);
new_img = filtering(img,mask,1,index);
axes(handles.axes2)
imshow(new_img)
handles.img2 = new_img;
guidata(hObject,handles);
time = toc;
set(handles.text1, 'String', strcat('Time:',num2str(time)));


function new_img = filtering(img,mask,padding,index)
img = double(img);
imgsize = size(img);
masksize = length(mask);
adjust = (masksize-1)/2;
channel = 0;
if length(imgsize) == 2
    img(:,:,2) = zeros(imgsize);
    img(:,:,3) = zeros(imgsize);
    channel = 1;
end
if padding == 1
    img = [zeros(imgsize(1),adjust,3) img zeros(imgsize(1),adjust,3)];
    img = [zeros(adjust,imgsize(2)+adjust*2,3); img; zeros(adjust,imgsize(2)+adjust*2,3)];
elseif padding == 2
    for i=1:adjust
        img = [img(:,i+1,:) img img(:,imgsize(2)-i,:)];
        img = [img(i+1,:,:); img; img(imgsize(1)-i,:,:)];
        img(1,1,:) = img(3,3,:);
        img(1,imgsize(2),:) = img(3,imgsize(2)-2,:);
        img(imgsize(1),1,:) = img(imgsize(1)-2,3,:);
        img(imgsize(1),imgsize(2),:) = img(imgsize(1)-2,imgsize(2)-2,:);
    end
elseif padding == 3
    for i=1:adjust
        img = [img(:,1,:) img img(:,imgsize(2),:)];
        img = [img(1,:,:); img; img(imgsize(1),:,:)];
        img(1,1,:) = img(2,2,:);
        img(1,imgsize(2),:) = img(2,imgsize(2)-1,:);
        img(imgsize(1),1,:) = img(imgsize(1)-1,2,:);
        img(imgsize(1),imgsize(2),:) = img(imgsize(1)-1,imgsize(2)-1,:);
    end
end
new_img = zeros(imgsize);
new_imgsize = size(new_img);
for i=1:new_imgsize(1)
    for j=1:new_imgsize(2)
        for k=1:3
            new_img(i,j,k) = 0;
            values = zeros(masksize^2,1);
            for l=1:masksize^2
                new_img(i,j,k) = new_img(i,j,k) + mask(l) * img(i+mod(l-1,masksize),j+floor(l/(masksize*1.01)),k);
                values(l) = mask(l) * img(i+mod(l-1,masksize),j+floor(l/(masksize*1.01)),k);
            end
            if index == 7
                new_img(i,j,k) = median(values);
            elseif index == 8
                new_img(i,j,k) = max(values);
            elseif index == 9
                new_img(i,j,k) = min(values);
            end
        end
    end
end 
if channel == 1
    new_img(:,:,2:3) = [];
end
new_img = uint8(new_img);


% --- Executes on button press in pushbutton3.
function pushbutton3_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
tic
img2 = handles.img2;
mask = handles.mask;
index = handles.index;
mask = fliplr(mask);
mask = flipud(mask);
new_img = filtering(img2,mask,1,index);
axes(handles.axes3)
imshow(new_img)
handles.img3 = new_img;
guidata(hObject,handles);
time = toc;
set(handles.text1, 'String', strcat('Time:',num2str(time)));


% --- Executes on button press in pushbutton4.
function pushbutton4_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
axes(handles.axes2)
imsave

% --- Executes on button press in pushbutton5.
function pushbutton5_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
axes(handles.axes3)
imsave


% --- Executes on button press in pushbutton6.
function pushbutton6_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
tic
img = handles.img3;
imgsize = size(img);
if length(imgsize) == 3
    img(:,:,2:3) = [];
end
BW1 = edge(img, 'zerocross');
BW2 = edge(img, 'log');
axes(handles.axes4)
imshow(BW1)
time = toc;
set(handles.text1, 'String', strcat('Time:',num2str(time)));


% --- Executes on slider movement.
function slider1_Callback(hObject, eventdata, handles)
% hObject    handle to slider1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
tic
threshold = get(handles.slider1, 'Value');
img = handles.img3;
imgsize = size(img);
if length(imgsize) == 3
    img(:,:,2:3) = [];
end
BW1 = edge(img, 'zerocross',threshold);
BW2 = edge(img, 'log');
axes(handles.axes4)
imshow(BW1)
time = toc;
set(handles.text1, 'String', strcat('Time:',num2str(time)));

% --- Executes during object creation, after setting all properties.
function slider1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on button press in pushbutton7.
function pushbutton7_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
axes(handles.axes4)
imsave

%%
name = ['Image 3-1';'Image 3-2';'Image 3-3';'Image 3-4';'Image 4-1'];
time = [2.7977 3.1592 3.8567 4.9261 5.9947 7.5979;2.435 2.698 3.2351 3.894 4.8127 6.0268;1.9512 2.2063 2.5614 3.1062 3.8156 4.6516;13.6046 15.5401 19.2298 24.8801 31.2901 40.8132;1.5725 1.7877 2.1824 2.5695 3.1872 4.0468];
plot(1:2:11,time(1,:),'-o',1:2:11,time(2,:),'-o',1:2:11,time(3,:),'-o',1:2:11,time(4,:),'-o',1:2:11,time(5,:),'-o')
legend(name)
xlabel('Size of filter')
ylabel('Time consumed')
title('Influence of filter size on time')


