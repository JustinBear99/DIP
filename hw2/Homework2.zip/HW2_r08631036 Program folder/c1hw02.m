function varargout = c1hw02(varargin)
% C1HW02 MATLAB code for c1hw02.fig
%      C1HW02, by itself, creates a new C1HW02 or raises the existing
%      singleton*.
%
%      H = C1HW02 returns the handle to a new C1HW02 or the handle to
%      the existing singleton*.
%
%      C1HW02('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in C1HW02.M with the given input arguments.
%
%      C1HW02('Property','Value',...) creates a new C1HW02 or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before c1hw02_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to c1hw02_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help c1hw02

% Last Modified by GUIDE v2.5 08-Oct-2019 16:36:49

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @c1hw02_OpeningFcn, ...
                   'gui_OutputFcn',  @c1hw02_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before c1hw02 is made visible.
function c1hw02_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to c1hw02 (see VARARGIN)

% Choose default command line output for c1hw02
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes c1hw02 wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = c1hw02_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes when figure1 is resized.
function figure1_SizeChangedFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[filename pathname]=uigetfile({'*.jpg';'*.bmp'},'Select image','C:\Users\USERS\desktop');
if(filename ~=0)
    img=strcat(pathname, filename);        %Ū�ɮ� �w�]���|���ୱ
    fileID = fopen(img,'r');
    A = fscanf(fileID,'%s');
    fclose(fileID);
else
    return;
end
img = imread(img);                         %�Huint8�榡Ū�i�Ϥ�
handles.img = img;                         %��iglobal variable�̨Ѩ�Lfunction�ϥ�
guidata(hObject,handles);
img = double(img);                         %���ާ@�e���ରdouble �~���|�Q�W�U���z�Z
img_grayscale1 = (img(:,:,1) + img(:,:,2) + img(:,:,3))/3;      %�Ĥ@�ئǶ�
img_grayscale2 = img(:,:,1)*0.299 + img(:,:,2)*0.587 + img(:,:,3)*0.114;   %�ĤG��
img_grayscale3 = imsubtract(img_grayscale1,img_grayscale2);     %�ĤT��
img = uint8(img);
img_grayscale1 = uint8(img_grayscale1);
img_grayscale2 = uint8(img_grayscale2);                         %�H�U���O��榡 �q�� �qhistogram
img_grayscale3 = uint8(img_grayscale3);

axes(handles.axes1)
imshow(img)
axes(handles.axes2)
imshow(img_grayscale1)
axes(handles.axes3)
imhist(img_grayscale1)
axes(handles.axes4)
imshow(img_grayscale2)
axes(handles.axes5)
imhist(img_grayscale2)

axes(handles.axes6)
imshow(img_grayscale3)
axes(handles.axes7)
imhist(img_grayscale3)


% --- Executes on slider movement.
function slider1_Callback(hObject, eventdata, handles)
% hObject    handle to slider1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
threshold = get(handles.slider1, 'Value');                        %��slider�ȨM�w�নbinary image���H��
img = handles.img;
img = double(img);
img_grayscale = (img(:,:,1) + img(:,:,2) + img(:,:,3))/3;
img_bw = zeros(length(img_grayscale(:,1)),length(img_grayscale(1,:))); %preallocation
for i=1:length(img_grayscale(:,1))
    for j=1:length(img_grayscale(1,:))
        if img_grayscale(i,j) > threshold
            img_bw(i,j) = 255;
        else
            img_bw(i,j) = 0;
        end
    end
end
img_bw = uint8(img_bw);
axes(handles.axes8)
imshow(img_bw)
axes(handles.axes9)
imhist(img_bw)


% --- Executes during object creation, after setting all properties.
function slider1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on slider movement.
function slider3_Callback(hObject, eventdata, handles)
% hObject    handle to slider3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
brightness = get(handles.slider3, 'Value');        %slider3 �Mslider4���O���վ�G�׻P���ת�function
handles.brightness = brightness;                   %�ѩ�ڳ]�p���O�n�P��Ū��ذѼ� �ҥH�C���վ㳣�n��o�ⶵ�Ѽ�
guidata(hObject,handles);                          %�ɭP����{�������� ���L���I���Ӧb���ת��ഫ���

img = handles.img;
contrast = handles.contrast;

imgsize = size(img);
new_img = zeros(imgsize(1),imgsize(2),imgsize(3));
new_imgsize = size(new_img);
for i=1:new_imgsize(1)                             %�վ�G�ת����� �n�`�N���O����ȹF��255�ɭn���L���n�A�[
    for j=1:new_imgsize(2)                         %���M�C��|�]��
        for k=1:new_imgsize(3)
            if img(i,j,k) == 255
                new_img(i,j,k) = img(i,j,k);
            else
                new_img(i,j,k) = img(i,j,k) + brightness;
            end
        end
    end
end

for i=1:length(new_img(:,1,1))                 %���ת��t��k 
    for j=1:length(new_img(1,:,1))
        for k=1:length(new_img(1,1,:))
            if new_img(i,j,k) < (128-96/contrast)
                new_img(i,j,k) = new_img(i,j,k)*32/(128-96/contrast);
            elseif (new_img(i,j,k) >= (128-96/contrast)) && (new_img(i,j,k) <= (128+96/contrast))
                new_img(i,j,k) = new_img(i,j,k)*contrast - 128*(contrast-1);
            elseif new_img(i,j,k) > (128+96/contrast)
                new_img(i,j,k) = new_img(i,j,k)*32/(128-96/contrast) + 256*(1-32/(128-96/contrast));
            end
        end
    end
end
new_img = uint8(new_img);
axes(handles.axes14)
imshow(new_img)


% --- Executes during object creation, after setting all properties.
function slider3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end
handles.brightness = 0;
set(hObject, 'Value', 0)
guidata(hObject,handles);


% --- Executes on slider movement.
function slider4_Callback(hObject, eventdata, handles)
% hObject    handle to slider4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
contrast = get(handles.slider4, 'Value');
handles.contrast = contrast;
guidata(hObject,handles);

img = handles.img;
brightness = handles.brightness;

imgsize = size(img);
new_img = zeros(imgsize(1),imgsize(2),imgsize(3));
new_imgsize = size(new_img);
for i=1:new_imgsize(1)
    for j=1:new_imgsize(2)
        for k=1:new_imgsize(3)
            if img(i,j,k) == 255
                new_img(i,j,k) = img(i,j,k);
            else
                new_img(i,j,k) = img(i,j,k) + brightness;
            end
        end
    end
end
for i=1:length(new_img(:,1,1))
    for j=1:length(new_img(1,:,1))
        for k=1:3
            if new_img(i,j,k) < (128-96/contrast)
                new_img(i,j,k) = new_img(i,j,k)*32/(128-96/contrast);
            elseif (new_img(i,j,k) >= (128-96/contrast)) || (new_img(i,j,k) <= (128+96/contrast))
                new_img(i,j,k) = new_img(i,j,k)*contrast - 128*(contrast-1);
            elseif new_img(i,j,k) > (128+96/contrast)
                new_img(i,j,k) = new_img(i,j,k)*32/(128-96/contrast) + 256*(1-32/(128-96/contrast));
            end
        end
    end
end
new_img = uint8(new_img);
axes(handles.axes14)
imshow(new_img)


% --- Executes during object creation, after setting all properties.
function slider4_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end
handles.contrast = 1;
set(hObject, 'Value', 1)
guidata(hObject,handles);


function new_img = histogram_equalization(img)
[counts,binLocations] = imhist(img);
total = sum(counts);
pr = zeros(256,1);                     %���ӦѮv�W�ұбo�覡 �Ʀ��{��
T = zeros(256,1);
T(1) = counts(1)/total;
for i=1:256
    pr(i) = counts(i)/total;
    if i>1
        T(i) = T(i-1) + pr(i);
    end
end
new_img = zeros(length(img(:,1)),length(img(1,:)));
for i=1:length(img(:,1))
    for j=1:length(img(1,:))
        new_img(i,j) = 255*T(img(i,j)+1);
    end
end
new_img = uint8(new_img);



% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
img = handles.img;
img=double(img);
img_grayscale = (img(:,:,1) + img(:,:,2) + img(:,:,3))/3;
img_grayscale = uint8(img_grayscale);
equalized_img = histogram_equalization(img_grayscale);  %histogram equilization
axes(handles.axes15)
imshow(equalized_img)

%�H�U��pushbutton3.4.5.6.7���O�������Y��0.33x 0.5x 2x 3x �P save
%����O�Q���Y��o�ӥ\��g���@�ӹ���Y��j�puniversal���@�ӥ\�� �ҥH��function(resize)�h�g��
%���g��@�b�g���U�h �N�令�u���|���Y��j�p �ҥH�|�h�@�Ӹ�resize ��function
%��������k���bresize�o��function�̭� �U�������s�u�O���Ʃʪ��@�~
% --- Executes on button press in pushbutton3.
function pushbutton3_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
img = handles.img;
multiple = 0.333;

resized_img = resize(img,multiple);
resized_img = double(resized_img);
resized_img_grayscale = (resized_img(:,:,1) + resized_img(:,:,2) + resized_img(:,:,3))/3;
resized_img = uint8(resized_img);
resized_img_grayscale = uint8(resized_img_grayscale);

axes(handles.axes10)
imshow(resized_img)
axes(handles.axes11)
imhist(resized_img)
axes(handles.axes12)
imshow(resized_img_grayscale)
axes(handles.axes13)
imhist(resized_img_grayscale)
disp(size(resized_img))

% --- Executes on button press in pushbutton4.
function pushbutton4_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
img = handles.img;
multiple = 0.5;

resized_img = resize(img,multiple);
resized_img = double(resized_img);
resized_img_grayscale = (resized_img(:,:,1) + resized_img(:,:,2) + resized_img(:,:,3))/3;
resized_img = uint8(resized_img);
resized_img_grayscale = uint8(resized_img_grayscale);

axes(handles.axes10)
imshow(resized_img)
axes(handles.axes11)
imhist(resized_img)
axes(handles.axes12)
imshow(resized_img_grayscale)
axes(handles.axes13)
imhist(resized_img_grayscale)
disp(size(resized_img))

% --- Executes on button press in pushbutton5.
function pushbutton5_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
img = handles.img;
multiple = 2;

resized_img = resize(img,multiple);
resized_img = double(resized_img);
resized_img_grayscale = (resized_img(:,:,1) + resized_img(:,:,2) + resized_img(:,:,3))/3;
resized_img = uint8(resized_img);
resized_img_grayscale = uint8(resized_img_grayscale);

axes(handles.axes10)
imshow(resized_img)
axes(handles.axes11)
imhist(resized_img)
axes(handles.axes12)
imshow(resized_img_grayscale)
axes(handles.axes13)
imhist(resized_img_grayscale)
disp(size(resized_img))


% --- Executes on button press in pushbutton6.
function pushbutton6_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
img = handles.img;
multiple = 3;

resized_img = resize(img,multiple);
resized_img = double(resized_img);
resized_img_grayscale = (resized_img(:,:,1) + resized_img(:,:,2) + resized_img(:,:,3))/3;
resized_img = uint8(resized_img);
resized_img_grayscale = uint8(resized_img_grayscale);

axes(handles.axes10)
imshow(resized_img)
axes(handles.axes11)
imhist(resized_img)
axes(handles.axes12)
imshow(resized_img_grayscale)
axes(handles.axes13)
imhist(resized_img_grayscale)
disp(size(resized_img))

%�Y��Ϥ���function
function resized_img = resize(img,multiple)
img = double(img);
imgsize = size(img);
resized_img = ones(int16(imgsize(1)*multiple),int16(imgsize(2)*multiple),imgsize(3))*-1;
resized_imgsize = size(resized_img);

if multiple == 2
   for i=1:imgsize(1)
       for j=1:imgsize(2)
           for k=1:imgsize(3)
               resized_img(2*i-1,2*j-1,k) = img(i,j,k);
           end
       end
   end 
   for i=1:imgsize(1)-1
       for j=1:imgsize(2)-1
           for k=1:imgsize(3)
               resized_img(2*i-1,2*j,k) = (resized_img(2*i-1,2*j-1,k) + resized_img(2*i-1,2*j+1,k))/2;
               resized_img(2*i,2*j-1,k) = (resized_img(2*i-1,2*j-1,k) + resized_img(2*i+1,2*j-1,k))/2;
               resized_img(2*i,2*j+1,k) = (resized_img(2*i-1,2*j+1,k) + resized_img(2*i+1,2*j+1,k))/2;
               resized_img(2*i+1,2*j,k) = (resized_img(2*i+1,2*j-1,k) + resized_img(2*i+1,2*j+1,k))/2;
               resized_img(2*i,2*j,k) = (resized_img(2*i-1,2*j-1,k) + resized_img(2*i+1,2*j-1,k) + resized_img(2*i-1,2*j+1,k) + resized_img(2*i+1,2*j+1,k))/4;
           end
       end
   end
   for i=1:resized_imgsize(1)
       for j=1:resized_imgsize(2)
           for k=1:imgsize(3)
               if resized_img(i,j,k) == -1
                   resized_img(i,j,k) = 0;
               end
           end
       end
   end
end

if multiple == 3
   for i=1:imgsize(1)
       for j=1:imgsize(2)
           for k=1:imgsize(3)
               resized_img(3*i-2,3*j-2,k) = img(i,j,k);
           end
       end
   end 
   for i=1:imgsize(1)-1
       for j=1:imgsize(2)-1
           for k=1:imgsize(3)
               resized_img(3*i-2,3*j-1,k) = resized_img(3*i-2,3*j-2,k)*0.75 + resized_img(3*i-2,3*j+1,k)*0.25;
               resized_img(3*i-2,3*j,k) = resized_img(3*i-2,3*j-2,k)*0.25 + resized_img(3*i-2,3*j+1,k)*0.75;
               resized_img(3*i-1,3*j-2,k) = resized_img(3*i-2,3*j-2,k)*0.75 + resized_img(3*i+1,3*j-2,k)*0.25;
               resized_img(3*i,3*j-2,k) = resized_img(3*i-2,3*j-2,k)*0.25 + resized_img(3*i+1,3*j-2,k)*0.75;
               resized_img(3*i-1,3*j+1,k) = resized_img(3*i-2,3*j+1,k)*0.75 + resized_img(3*i+1,3*j+1,k)*0.25;
               resized_img(3*i,3*j+1,k) = resized_img(3*i-2,3*j+1,k)*0.25 + resized_img(3*i+1,3*j+1,k)*0.75;
               resized_img(3*i+1,3*j-1,k) = resized_img(3*i+1,3*j-2,k)*0.75 + resized_img(3*i+1,3*j+1,k)*0.25;
               resized_img(3*i+1,3*j,k) = resized_img(3*i+1,3*j-2,k)*0.25 + resized_img(3*i+1,3*j+1,k)*0.75;
               resized_img(3*i-1,3*j-1,k) = resized_img(3*i-2,3*j-2,k)*0.75 + resized_img(3*i+1,3*j+1,k)*0.25;
               resized_img(3*i,3*j,k) = resized_img(3*i-2,3*j-2,k)*0.25 + resized_img(3*i+1,3*j+1,k)*0.75;
               resized_img(3*i-1,3*j,k) = resized_img(3*i-2,3*j+1,k)*0.75 + resized_img(3*i+1,3*j-2,k)*0.25;
               resized_img(3*i,3*j-1,k) = resized_img(3*i-2,3*j+1,k)*0.25 + resized_img(3*i+1,3*j-2,k)*0.75;
           end
       end
   end
   for i=1:resized_imgsize(1)
       for j=1:resized_imgsize(2)
           for k=1:imgsize(3)
               if resized_img(i,j,k) == -1
                   resized_img(i,j,k) = 0;
               end
           end
       end
   end
end

if multiple == 0.5
   for i=1:resized_imgsize(1)
       for j=1:resized_imgsize(2)
           for k=1:imgsize(3)
               resized_img(i,j,k) = (img(2*i-1,2*j-1,k) + img(2*i-1,2*j,k) + img(2*i,2*j-1,k) + img(2*i,2*j,k))/4;
           end
       end
   end
   for i=1:resized_imgsize(1)
       for j=1:resized_imgsize(2)
           for k=1:imgsize(3)
               if resized_img(i,j,k) == -1
                   resized_img(i,j,k) = 0;
               end
           end
       end
   end
end

if multiple == 0.333
   for i=1:resized_imgsize(1)-1
       for j=1:resized_imgsize(2)-1
           for k=1:imgsize(3)
               resized_img(i,j,k) = (img(3*i-2,3*j-2,k) + img(3*i-2,3*j-1,k) + img(3*i-2,3*j,k) + img(3*i-1,3*j-2,k) + img(3*i-1,3*j-1,k) + img(3*i-1,3*j,k) + img(3*i,3*j-2,k) + img(3*i,3*j-1,k) + img(3*i,3*j,k))/9;
           end
       end
   end
   for i=1:resized_imgsize(1)
       for j=1:resized_imgsize(2)
           for k=1:imgsize(3)
               if resized_img(i,j,k) == -1
                   resized_img(i,j,k) = 0;
               end
           end
       end
   end
end
resized_img = uint8(resized_img);


% --- Executes on button press in pushbutton7.
function pushbutton7_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
axes(handles.axes10)
imsave
